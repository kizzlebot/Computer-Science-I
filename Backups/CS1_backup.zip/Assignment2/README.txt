After a round of speed-dating
	Each man rates each woman with score 1-10
	Each woman rates each man with score 1-10
Then using this data, 
	Every person is matched up in a way that maximizes the Total Group's Likeability Quotient


Likeability Quotient
-- For each couple in the matching, look at how much the man likes the woman and the woman likes the man.  (Both of these will be numbers from 1 to 10.) Record the minimum of the two numbers.
-- The sum of all these minimums is the entire group's likeability quotient
------ Exceptions:
-------- if more than one matching leads to the same maximal likeability quotient
			-- Minimize Difference in Likeability between all pairs
				-- for each couple in matching
					-- Sum difference (a-b if a>b) and (b-a if b>a)
				-- Smaller difference is better 

