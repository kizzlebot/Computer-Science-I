Carlos's CS1 Assignment
I practice too.
