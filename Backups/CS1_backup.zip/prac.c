#include <stdio.h>
#include <stdlib.h>

int main(){
	char ch = ' ' ;
	printf("%d",ch);
}