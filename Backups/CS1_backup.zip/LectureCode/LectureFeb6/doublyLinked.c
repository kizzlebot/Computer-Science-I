#include <stdio.h>

/*
 *  Doubly Linked List - Deletion
 *		curr->prev->next = curr->next
 *		curr->next->prev = curr->prev
 *		free(curr)
 *		(Assuming curr->prev and curr->next are NOT NULL)
 *
 */

int main(){
}
