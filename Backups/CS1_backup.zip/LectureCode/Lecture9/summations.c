#include <stdio.h>


int main(){
	int i, j ;
	for (i = 0 ; i < sizeA ; i++){
		for ( j = 0 ; j < sizeB ; j++){
			// Order n^2
		}
	}

	// Sigma(sum,1,5) is equivalent to 
	int sum ; 
	for ( i = 1 ; i <= 5 ; i++){
		sum+= i ; 
	}

	// Sigma(c,a,b) = c*Sigma(1,a,b) = (b - a + 1)*c
	// Sigma(f(k)+g(k),a,b) = Sigma(f(k),a,b) + Sigma(g(k),a,b) 
	
}